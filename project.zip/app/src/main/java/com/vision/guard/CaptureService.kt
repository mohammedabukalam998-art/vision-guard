package com.vision.guard

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * يعتمد على نموذج NudeNet (YOLOv8، مدخل 640x640x3 float RGB بقيم 0..1،
 * مخرج [1, 22, 8400] = 4 إحداثيات للمربع + 18 فئة).
 * لا نحتاج المربعات ولا NMS: يكفي أن تتجاوز درجة فئة مراقَبة الحد في أي موضع.
 */
class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    // كل ما يلي يُلمس من خيط المعالجة فقط
    private val pixels = IntArray(INPUT * INPUT)
    private val letterbox = Bitmap.createBitmap(INPUT, INPUT, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(letterbox)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()
    private var contentW = INPUT
    private var contentH = INPUT

    private val inputBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(INPUT * INPUT * 3 * 4).order(ByteOrder.nativeOrder())
    private val outputBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(CHANNELS * ANCHORS * 4).order(ByteOrder.nativeOrder())
    private val outFloats = outputBuffer.asFloatBuffer()

    private val watchClasses: IntArray
    private val watchThresholds: FloatArray

    private var lastProcessed = 0L
    private var blocked = false
    private var probing = false

    private val probeRunnable = Runnable { startProbe() }
    private val probeTimeoutRunnable = Runnable { finishProbe() }

    init {
        val c = mutableListOf<Int>()
        val t = mutableListOf<Float>()
        for (cls in EXPOSED_CLASSES) { c += cls; t += EXPOSED_THRESHOLD }
        if (BLOCK_BELLY) { c += CLS_BELLY_EXPOSED; t += EXPOSED_THRESHOLD }
        if (BLOCK_COVERED) for (cls in COVERED_CLASSES) { c += cls; t += COVERED_THRESHOLD }
        watchClasses = c.toIntArray()
        watchThresholds = t.toFloatArray()
    }

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("vg-infer").also { it.start() }
        handler = Handler(thread.looper)
        // GPU delegate يجب إنشاؤه واستخدامه على نفس الخيط
        handler.post { initInterpreter() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        if (p == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { stopSelf() }
            }
        }, handler)

        startCapture(p)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "خدمة حماية البصر", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مرشح البصر يعمل الآن")
            .setContentText("حماية الشاشة مفعلة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    private fun initInterpreter() {
        try {
            val model = loadModelFile()
            interpreter = try {
                val gpu = GpuDelegate()
                gpuDelegate = gpu
                Interpreter(model, Interpreter.Options().addDelegate(gpu))
            } catch (e: Throwable) {
                Log.w(TAG, "GPU غير متاح، نستخدم CPU", e)
                gpuDelegate?.close()
                gpuDelegate = null
                Interpreter(model, Interpreter.Options().setNumThreads(4))
            }
        } catch (e: Throwable) {
            Log.e(TAG, "فشل تحميل النموذج $MODEL_FILE", e)
        }
    }

    private fun loadModelFile(): MappedByteBuffer {
        assets.openFd(MODEL_FILE).use { fd ->
            FileInputStream(fd.fileDescriptor).use { stream ->
                return stream.channel.map(
                    FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength
                )
            }
        }
    }

    // ---------------- الالتقاط ----------------

    private fun startCapture(p: MediaProjection) {
        val metrics = resources.displayMetrics
        val scale = minOf(
            1f, CAPTURE_MAX_SIDE.toFloat() / maxOf(metrics.widthPixels, metrics.heightPixels)
        )
        val w = (metrics.widthPixels * scale).toInt().coerceAtLeast(1)
        val h = (metrics.heightPixels * scale).toInt().coerceAtLeast(1)

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        virtualDisplay = p.createVirtualDisplay(
            "VisionGuardCapture", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
        reader.setOnImageAvailableListener({ onFrame(it) }, handler)
    }

    private fun onFrame(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        val now = SystemClock.elapsedRealtime()

        // الطبقة ظاهرة: اللقطة هي طبقتنا نفسها. وإلا نخفف المعالجة (النموذج ثقيل)
        if ((blocked && !probing) || (!probing && now - lastProcessed < MIN_INTERVAL_MS)) {
            image.close()
            return
        }
        lastProcessed = now

        val frame = try { imageToBitmap(image) } finally { image.close() }
        prepareInput(frame)
        frame.recycle()

        analyze()
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    /** يلصق الإطار في مربع 640x640 بحفظ النسبة (حشو أسود أسفل/يمين كما يفعل NudeNet). */
    private fun prepareInput(frame: Bitmap) {
        val s = INPUT.toFloat() / maxOf(frame.width, frame.height)
        contentW = (frame.width * s).toInt().coerceIn(1, INPUT)
        contentH = (frame.height * s).toInt().coerceIn(1, INPUT)
        canvas.drawColor(Color.BLACK)
        dst.set(0, 0, contentW, contentH)
        canvas.drawBitmap(frame, null, dst, paint)
        letterbox.getPixels(pixels, 0, INPUT, 0, 0, INPUT, INPUT)
    }

    // ---------------- التحليل ----------------

    private fun analyze() {
        // إحصاءات سريعة على منطقة المحتوى فقط (بدون الحشو)
        var skin = 0
        var lumaSum = 0L
        var n = 0
        var y = 0
        while (y < contentH) {
            var x = 0
            while (x < contentW) {
                val p = pixels[y * INPUT + x]
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                lumaSum += (r * 299 + g * 587 + b * 114) / 1000
                if (r > 95 && g > 40 && b > 20 &&
                    maxOf(r, g, b) - minOf(r, g, b) > 15 &&
                    Math.abs(r - g) > 15 && r > g && r > b
                ) skin++
                n++
                x += 4
            }
            y += 4
        }
        val meanLuma = lumaSum / n
        val skinRatio = skin.toFloat() / n

        // أثناء إعادة الفحص: لقطة سوداء تقريباً = ما زالت طبقتنا، غير حاسمة
        if (blocked && meanLuma < DARK_LUMA) return

        val worthChecking = !USE_SKIN_PREFILTER || skinRatio > MIN_SKIN_RATIO
        onVerdict(worthChecking && detect(skinRatio))
    }

    private fun detect(skinRatio: Float): Boolean {
        val interp = interpreter ?: return false

        inputBuffer.rewind()
        for (p in pixels) {
            inputBuffer.putFloat(Color.red(p) / 255f)
            inputBuffer.putFloat(Color.green(p) / 255f)
            inputBuffer.putFloat(Color.blue(p) / 255f)
        }
        inputBuffer.rewind()
        outputBuffer.rewind()

        val t0 = SystemClock.elapsedRealtime()
        interp.run(inputBuffer, outputBuffer)
        val ms = SystemClock.elapsedRealtime() - t0

        // الشكل [1, 22, 8400]: القناة c عند الفهرس c*8400 + a
        var hit = false
        for (i in watchClasses.indices) {
            val base = (4 + watchClasses[i]) * ANCHORS
            val thr = watchThresholds[i]
            for (a in 0 until ANCHORS) {
                if (outFloats.get(base + a) > thr) { hit = true; break }
            }
            if (hit) break
        }

        if (DEBUG) logBest(skinRatio, ms, hit)
        return hit
    }

    /** للمعايرة: يطبع أعلى درجة لكل فئة مهمة في Logcat (الوسم VisionGuard). */
    private fun logBest(skinRatio: Float, ms: Long, hit: Boolean) {
        val sb = StringBuilder("hit=$hit ${ms}ms skin=${"%.2f".format(skinRatio)} |")
        for (cls in 0 until 18) {
            var best = 0f
            val base = (4 + cls) * ANCHORS
            for (a in 0 until ANCHORS) {
                val v = outFloats.get(base + a)
                if (v > best) best = v
            }
            if (best > 0.15f) sb.append(" ${LABELS[cls]}=${"%.2f".format(best)}")
        }
        Log.d(TAG, sb.toString())
    }

    // ---------------- الحجب وإعادة الفحص ----------------

    private fun onVerdict(nsfw: Boolean) {
        if (nsfw) {
            handler.removeCallbacks(probeTimeoutRunnable)
            if (!blocked || probing) {
                blocked = true
                probing = false
                OverlayAccessibilityService.setBlocked(true)
            }
            handler.removeCallbacks(probeRunnable)
            handler.postDelayed(probeRunnable, HOLD_MS)
        } else if (probing) {
            finishProbe()
        }
    }

    private fun startProbe() {
        if (!blocked) return
        probing = true
        OverlayAccessibilityService.setBlocked(false)
        handler.postDelayed(probeTimeoutRunnable, PROBE_TIMEOUT_MS)
    }

    private fun finishProbe() {
        handler.removeCallbacks(probeTimeoutRunnable)
        probing = false
        blocked = false
        OverlayAccessibilityService.setBlocked(false)
    }

    // ---------------- الإنهاء ----------------

    override fun onDestroy() {
        super.onDestroy()
        OverlayAccessibilityService.setBlocked(false)
        imageReader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        projection = null
        handler.removeCallbacksAndMessages(null)
        handler.post {
            interpreter?.close()
            gpuDelegate?.close()
            letterbox.recycle()
            thread.quitSafely()
        }
    }

    companion object {
        const val EXTRA_CODE = "RESULT_CODE"
        const val EXTRA_DATA = "DATA"

        private const val TAG = "VisionGuard"
        private const val CHANNEL_ID = "VisionGuard_Channel"
        private const val MODEL_FILE = "nudenet.tflite"

        // شكل النموذج كما قرأته من الملف: مدخل [1,640,640,3] ومخرج [1,22,8400]
        private const val INPUT = 640
        private const val ANCHORS = 8400
        private const val CHANNELS = 22

        // ترتيب فئات NudeNet v3 (من معرفتي بالمشروع الأصلي؛ تحقق منه بسجل DEBUG)
        private val LABELS = arrayOf(
            "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED",
            "FEMALE_BREAST_EXPOSED", "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED",
            "ANUS_EXPOSED", "FEET_EXPOSED", "BELLY_COVERED", "FEET_COVERED",
            "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE", "BELLY_EXPOSED",
            "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED"
        )

        private const val CLS_BELLY_EXPOSED = 13
        // أجزاء مكشوفة: مؤخرة، صدر أنثى، عورة أنثى، شرج، عورة ذكر
        private val EXPOSED_CLASSES = intArrayOf(2, 3, 4, 6, 14)
        // أجزاء مغطاة (قد تلتقط ملابس السباحة والملابس الضيقة، لكنها تُحدث حجباً خاطئاً كثيراً)
        private val COVERED_CLASSES = intArrayOf(0, 15, 16, 17)

        // ---- إعدادات يمكنك تعديلها بعد التجربة ----
        private const val DEBUG = true            // اجعلها false قبل النشر
        private const val BLOCK_BELLY = true      // البطن المكشوف (يشمل الرجال أيضاً)
        private const val BLOCK_COVERED = false   // فعّلها لتشدد أكثر في شبه العري
        private const val EXPOSED_THRESHOLD = 0.35f
        private const val COVERED_THRESHOLD = 0.60f

        private const val USE_SKIN_PREFILTER = true
        private const val MIN_SKIN_RATIO = 0.03f
        private const val DARK_LUMA = 12

        private const val CAPTURE_MAX_SIDE = 960
        private const val MIN_INTERVAL_MS = 800L
        private const val HOLD_MS = 3000L
        private const val PROBE_TIMEOUT_MS = 2500L
    }
}
