package com.vision.guard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView

class OverlayAccessibilityService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private var overlay: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    private fun show() {
        if (overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val view = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#F2000000"))
            addView(
                TextView(context).apply {
                    text = "تم حجب محتوى غير لائق"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                },
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, params)
            overlay = view
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hide() {
        val view = overlay ?: return
        overlay = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (_: IllegalArgumentException) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        main.post { hide() }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        main.post { hide() }
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: OverlayAccessibilityService? = null

        /** آمنة الاستدعاء من أي خيط. */
        fun setBlocked(blocked: Boolean) {
            val s = instance ?: return
            s.main.post { if (blocked) s.show() else s.hide() }
        }
    }
}
